﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using QApp.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace QApp.ViewModel
{
    public class StartWindowViewModel : ViewModelBase
    {
        #region [ Events ]
        public ICommand Command_Q1 { get; private set; }
        public ICommand Command_Q2 { get; private set; }
        public ICommand Command_Q3 { get; private set; }
        #endregion

        #region [ Constructor ]
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public StartWindowViewModel()
        {
            Command_Q1 = new RelayCommand(() => Q1(), () => true);

            Command_Q2 = new RelayCommand(() => Q2(), () => true);

            Command_Q3 = new RelayCommand(() => Q3(), () => true);
        }
        #endregion

        #region [ Methods ]
        public void Q1()
        {
            Q1View q1View = new Q1View();
            q1View.ShowDialog();
        }


        public void Q2()
        {
            Q2View q2View = new Q2View();
            q2View.ShowDialog();
        }

        public void Q3()
        {
            Q3View q3View = new Q3View();
            q3View.ShowDialog();
        }
        #endregion
    }
}
