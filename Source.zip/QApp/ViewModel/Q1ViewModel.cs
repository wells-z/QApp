using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System;
using QApp.Model;
using System.Collections.ObjectModel;
using QApp.Interface;
using GalaSoft.MvvmLight.Messaging;
using QApp.View;

namespace QApp.ViewModel
{
    public class Q1ViewModel : ViewModelBase, ICloseable
    {
        #region [ Events ]
        /// <summary>
        /// 
        /// </summary>
        public ICommand Command_Execute { get; private set; }

        /// <summary>
        /// Open FolderBrowserDialog Event
        /// </summary>
        public ICommand Command_SelectFolder { get; private set; }
        #endregion

        #region [ Constructor ]
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public Q1ViewModel()
        {
            Command_Execute = new RelayCommand(() => GetDeepestFiles(), () => true);

            Command_SelectFolder = new RelayCommand(() => SelectFolder(), () => true);
        }
        #endregion

        #region [ Methods ]
        public void GetDeepestFiles()
        {
            try
            {
                //Clear the result List
                FileModels.Clear();

                //Validation -- Path cannot be empty
                if (string.IsNullOrWhiteSpace(StrPath))
                {
                    System.Windows.MessageBox.Show("Path cannot be empty!", "Validation Error");
                    return;
                }

                //Validation -- It's a invalid path
                if (!Directory.Exists(StrPath))
                {
                    System.Windows.MessageBox.Show("It's a invalid path!", "Validation Error");
                    return;
                }

                IList<string> strList_CurrentDirectory = new List<string>();

                //Get all sub directories from the given path.
                IList<IList<string>> strList_AllDirectories = getAllDirectories(StrPath, ref strList_CurrentDirectory);
                GC.Collect();

                if (strList_AllDirectories.Count == 0)
                {
                    System.Windows.MessageBox.Show("There is no sub-folder in your given folder!", "Validation Error");
                    return;
                }

                #region [ Get files from the lowest depth folder -- if there are two folders in the same depth, system will show all files in these folders. ]
                var group = (from a in strList_AllDirectories
                             group a by new
                             {
                                 PathCount = a.Count
                             } into g
                             select new
                             {
                                 g.Key,
                                 g
                             }).OrderByDescending(current => current.Key.PathCount).ToList();

                var MaxPathList = group[0];

                foreach (var item in MaxPathList.g)
                {
                    string str_FullPath = Path.Combine(item.ToArray());

                    str_FullPath = Path.Combine(StrPath.Remove(StrPath.LastIndexOf(@"\") + 1), str_FullPath);

                    List<string> strList_Files = Directory.GetFiles(str_FullPath).Where(current => current.Substring(current.Length - 4).ToLower() == ".txt").ToList();

                    foreach (var item_File in strList_Files)
                    {
                        FileModels.Add(new FileModel(item_File));
                    }
                }
                GC.Collect();
                #endregion

                if (FileModels.Count == 0)
                {
                    System.Windows.MessageBox.Show("There is no file in the lowest depth folder!", "Validation Error");
                    return;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message.ToString(), "System Error");
                return;
            }
        }

        /// <summary>
        /// Get All Directories -- Recursive Method
        /// </summary>
        /// <param name="str_Path"></param>
        /// <param name="strList_CurrentDirectory"></param>
        /// <returns></returns>
        private IList<IList<string>> getAllDirectories(string str_Path, ref IList<string> strList_CurrentDirectory)
        {
            IList<IList<string>> ret = new List<IList<string>>();
            if (!string.IsNullOrWhiteSpace(str_Path))
            {
                string[] strArray_SubDirectory = Directory.GetDirectories(str_Path);

                string str_FolderName = str_Path.Substring(str_Path.LastIndexOf(@"\") + 1);
                strList_CurrentDirectory.Add(str_FolderName);

                if (strArray_SubDirectory.Length == 0)
                {
                    ret.Add(new List<string>(strList_CurrentDirectory));
                    strList_CurrentDirectory.RemoveAt(strList_CurrentDirectory.Count - 1);
                }
                else
                {
                    foreach (string directory in strArray_SubDirectory)
                    {
                        foreach (var subdirectory in getAllDirectories(directory, ref strList_CurrentDirectory))
                        {
                            ret.Add(subdirectory);
                        }
                    }
                    strList_CurrentDirectory.RemoveAt(strList_CurrentDirectory.Count - 1);
                }
            }
            return ret;
        }

        /// <summary>
        /// Open a FolderBrowserDialog.
        /// </summary>
        public void SelectFolder()
        {
            System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
            fbd.ShowDialog();
            if (fbd.SelectedPath != string.Empty)
                StrPath = fbd.SelectedPath;
        }
        #endregion

        #region [ Properties ]
        #region [ StrPath ]
        /// <summary>
        /// The <see cref="StrPath" /> property's name.
        /// </summary>
        public const string StrPathPropertyName = "StrPath";

        private string _StrPath = "";

        /// <summary>
        /// Sets and gets the StrPath property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string StrPath
        {
            get
            {
                return _StrPath;
            }

            set
            {
                if (_StrPath == value)
                {
                    return;
                }

                _StrPath = value;
                if (!string.IsNullOrWhiteSpace(_StrPath))
                    _CMDIsEnabled = true;
                else
                    _CMDIsEnabled = false;
                RaisePropertyChanged(CMDIsEnabledPropertyName);
                RaisePropertyChanged(StrPathPropertyName);
            }
        }
        #endregion

        #region [ CMDIsEnabled ]
        /// <summary>
        /// The <see cref="CMDIsEnabled" /> property's name.
        /// </summary>
        public const string CMDIsEnabledPropertyName = "CMDIsEnabled";

        private bool _CMDIsEnabled = false;

        /// <summary>
        /// Sets and gets the Path property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public bool CMDIsEnabled
        {
            get
            {
                return _CMDIsEnabled;
            }

            set
            {
                if (_CMDIsEnabled == value)
                {
                    return;
                }

                _CMDIsEnabled = value;
                RaisePropertyChanged(CMDIsEnabledPropertyName);
            }
        }
        #endregion

        #region [ FileModes ]
        /// <summary>
        /// The <see cref="FileModels" /> property's name.
        /// </summary>
        public const string FileModelsPropertyName = "FileModels";

        private ObservableCollection<FileModel> _FileModels = new ObservableCollection<FileModel>();

        /// <summary>
        /// Sets and gets the Members property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public ObservableCollection<FileModel> FileModels
        {
            get
            {
                return _FileModels;
            }

            set
            {
                if (_FileModels == value)
                {
                    return;
                }

                _FileModels = value;
                RaisePropertyChanged(FileModelsPropertyName);
            }
        }
        #endregion
        #endregion

        #region [ Close Window Event ]
        public override void Cleanup()
        {
            StrPath = "";
            CMDIsEnabled = false;
            FileModels.Clear();
        }

        private void CloseWindowExecute()
        {

            CloseExecute();
        }

        public event EventHandler<EventArgs> RequestClose;
        private void CloseExecute()
        {
            var handler = RequestClose;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        #endregion
    }
}