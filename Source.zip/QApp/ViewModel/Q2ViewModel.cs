﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using QApp.Interface;
using QApp.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace QApp.ViewModel
{
    public class Q2ViewModel : ViewModelBase, ICloseable
    {
        #region [ Events ]
        public ICommand Command_Calculate { get; private set; }
        #endregion

        #region [ Constructor ]
        public Q2ViewModel()
        {
            Command_Calculate = new RelayCommand(() => Calculate(), () => true);
        }
        #endregion

        #region [ Methods ]
        public void Calculate()
        {
            TextResult = "";

            try
            {
                #region [ Validation ]
                if (string.IsNullOrWhiteSpace(Train1Speed) || _Train1Speed <= 0)
                {
                    System.Windows.MessageBox.Show("Train 1 speed must be greater than 0 miles/hour!", "Validation Error");
                    return;
                }

                if (string.IsNullOrWhiteSpace(Train2Speed) || _Train2Speed <= 0)
                {
                    System.Windows.MessageBox.Show("Train 2 speed must be greater than 0 miles/hour!", "Validation Error");
                    return;
                }

                if (string.IsNullOrWhiteSpace(Distance) || _Distance <= 0)
                {
                    System.Windows.MessageBox.Show("Distance must be greater than 0 miles!", "Validation Error");
                    return;
                }
                #endregion

                double Train1Distance = _Distance * _Train1Speed / (_Train1Speed + _Train2Speed);
                double Train2Distance = _Distance * _Train2Speed / (_Train1Speed + _Train2Speed);

                Train1Distance = Math.Round(Train1Distance, 2);
                Train2Distance = Math.Round(Train2Distance, 2);

                //Fix rounding issue.
                if (_Distance != (Train1Distance + Train2Distance))
                {
                    if (Train1Distance > Train2Distance)
                        Train1Distance = _Distance - (Train1Distance + Train2Distance) + Train1Distance;
                    else
                        Train2Distance = _Distance - (Train1Distance + Train2Distance) + Train1Distance;
                }

                double Train1Min = Train1Distance / _Train1Speed * 60;
                double Train2Min = Train2Distance / _Train2Speed * 60;

                double usedMin = (Train1Min + Train2Min) / 2;

                //Rounding off to 2 decimal places 
                usedMin = Math.Round(usedMin, 2);

                TextResult = "After " + usedMin.ToString() + " mins, the two trains will pass each other, train 1 will travel " + Train1Distance.ToString() + " miles and train 2 will travel " + Train2Distance.ToString() + " miles.";
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message.ToString(), "System Error");
                return;
            }
        }
        #endregion

        #region [ Properties ]
        #region [ Distance ]
        /// <summary>
        /// The <see cref="Distance" /> property's name.
        /// </summary>
        public const string DistancePropertyName = "Distance";

        private double _Distance = 0;

        /// <summary>
        /// Sets and gets the Distance property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string Distance
        {
            get
            {
                if (_Distance == 0)
                    return "";
                return _Distance.ToString();
            }

            set
            {
                if (_Distance.ToString() == value)
                {
                    return;
                }

                double temp = 0;
                if (string.IsNullOrWhiteSpace(value) || !double.TryParse(value, out temp))
                    _Distance = 0;
                else
                    _Distance = Convert.ToDouble(value);

                if (_Distance > 0 && _Train1Speed > 0 && _Train2Speed > 0)
                    _CMDIsEnabled = true;
                else
                    _CMDIsEnabled = false;
                RaisePropertyChanged(CMDIsEnabledPropertyName);

                RaisePropertyChanged(DistancePropertyName);
            }
        }
        #endregion

        #region [ Train 1 Speed ]
        /// <summary>
        /// The <see cref="Train1Speed" /> property's name.
        /// </summary>
        public const string Train1SpeedPropertyName = "Train1Speed";

        private double _Train1Speed = 0;

        /// <summary>
        /// Sets and gets the Train1Speed property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string Train1Speed
        {
            get
            {
                if (_Train1Speed == 0)
                    return "";
                return _Train1Speed.ToString();
            }

            set
            {
                if (_Train1Speed.ToString() == value)
                {
                    return;
                }

                double temp = 0;
                if (string.IsNullOrWhiteSpace(value) || !double.TryParse(value, out temp))
                    _Train1Speed = 0;
                else
                    _Train1Speed = Convert.ToDouble(value);

                if (_Distance > 0 && _Train1Speed > 0 && _Train2Speed > 0)
                    _CMDIsEnabled = true;
                else
                    _CMDIsEnabled = false;
                RaisePropertyChanged(CMDIsEnabledPropertyName);

                RaisePropertyChanged(Train1SpeedPropertyName);
            }
        }
        #endregion

        #region [ Train 2 Speed ]
        /// <summary>
        /// The <see cref="Train2Speed" /> property's name.
        /// </summary>
        public const string Train2SpeedPropertyName = "Train2Speed";

        private double _Train2Speed = 0;

        /// <summary>
        /// Sets and gets the Train2Speed property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string Train2Speed
        {
            get
            {
                if (_Train1Speed == 0)
                    return "";
                return _Train2Speed.ToString();
            }

            set
            {
                if (_Train2Speed.ToString() == value)
                {
                    return;
                }

                double temp = 0;
                if (string.IsNullOrWhiteSpace(value) || !double.TryParse(value, out temp))
                    _Train2Speed = 0;
                else
                    _Train2Speed = Convert.ToDouble(value);

                if (_Distance > 0 && _Train1Speed > 0 && _Train2Speed > 0)
                    _CMDIsEnabled = true;
                else
                    _CMDIsEnabled = false;
                RaisePropertyChanged(CMDIsEnabledPropertyName);

                RaisePropertyChanged(Train2SpeedPropertyName);
            }
        }
        #endregion

        #region [ CMDIsEnabled ]
        /// <summary>
        /// The <see cref="CMDIsEnabled" /> property's name.
        /// </summary>
        public const string CMDIsEnabledPropertyName = "CMDIsEnabled";

        private bool _CMDIsEnabled = false;

        /// <summary>
        /// Sets and gets the Path property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public bool CMDIsEnabled
        {
            get
            {
                return _CMDIsEnabled;
            }

            set
            {
                if (_CMDIsEnabled == value)
                {
                    return;
                }

                _CMDIsEnabled = value;
                RaisePropertyChanged(CMDIsEnabledPropertyName);
            }
        }
        #endregion

        #region [ TextResult ]
        /// <summary>
        /// The <see cref="TextResult" /> property's name.
        /// </summary>
        public const string TextResultPropertyName = "TextResult";

        private string _TextResult = "";

        /// <summary>
        /// Sets and gets the TextResult property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string TextResult
        {
            get
            {
                return _TextResult;
            }

            set
            {
                if (_TextResult == value)
                {
                    return;
                }

                _TextResult = value;
                RaisePropertyChanged(TextResultPropertyName);
            }
        }
        #endregion
        #endregion

        #region [ Close Window Event ]
        public override void Cleanup()
        {
            Distance = "";
            Train1Speed = "";
            Train2Speed = "";
            CMDIsEnabled = false;
            TextResult = "";
        }
        private void CloseWindowExecute()
        {
            CloseExecute();
        }

        public event EventHandler<EventArgs> RequestClose;
        private void CloseExecute()
        {
            var handler = RequestClose;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        #endregion
    }
}
