/*
  In App.xaml:
  <Application.Resources>
      <vm:ViewModelLocator xmlns:vm="clr-namespace:QApp"
                           x:Key="Locator" />
  </Application.Resources>
  
  In the View:
  DataContext="{Binding Source={StaticResource Locator}, Path=ViewModelName}"

  You can also use Blend to do all this with the tool's support.
  See http://www.galasoft.ch/mvvm
*/

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Messaging;
using Microsoft.Practices.ServiceLocation;
using System.Windows;

namespace QApp.ViewModel
{
    /// <summary>
    /// This class contains static references to all the view models in the
    /// application and provides an entry point for the bindings.
    /// </summary>
    public class ViewModelLocator
    {
        #region [ Constructor ]
        /// <summary>
        /// Initializes a new instance of the ViewModelLocator class.
        /// </summary>
        public ViewModelLocator()
        {
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

            ////if (ViewModelBase.IsInDesignModeStatic)
            ////{
            ////    // Create design time view services and models
            ////    SimpleIoc.Default.Register<IDataService, DesignDataService>();
            ////}
            ////else
            ////{
            ////    // Create run time view services and models
            ////    SimpleIoc.Default.Register<IDataService, DataService>();
            ////}

            SimpleIoc.Default.Register<Q1ViewModel>();
            SimpleIoc.Default.Register<Q2ViewModel>();
            SimpleIoc.Default.Register<Q3ViewModel>();
            SimpleIoc.Default.Register<StartWindowViewModel>();
        }
        #endregion

        #region [ Properties - ViewModel ]
        public Q1ViewModel Q1
        {
            get
            {
                return ServiceLocator.Current.GetInstance<Q1ViewModel>();
            }
        }

        public Q2ViewModel Q2
        {
            get
            {
                return ServiceLocator.Current.GetInstance<Q2ViewModel>();
            }
        }

        public Q3ViewModel Q3
        {
            get
            {
                return ServiceLocator.Current.GetInstance<Q3ViewModel>();
            }
        }

        public StartWindowViewModel StartWindowVM
        {
            get
            {
                return ServiceLocator.Current.GetInstance<StartWindowViewModel>();
            }
        }
        #endregion

        #region [ Methods ]
        public static void Cleanup()
        {
            // TODO Clear the ViewModels
            var viewModelLocator = (ViewModelLocator)Application.Current.Resources["Locator"];
            viewModelLocator.Q1.Cleanup();
            viewModelLocator.Q2.Cleanup();
            viewModelLocator.Q3.Cleanup();
        }
        #endregion
    }
}