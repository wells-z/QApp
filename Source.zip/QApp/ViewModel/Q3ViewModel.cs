﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;
using GalaSoft.MvvmLight.Messaging;
using QApp.Interface;
using QApp.Model;
using QApp.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

namespace QApp.ViewModel
{
    public class Q3ViewModel : ViewModelBase, ICloseable
    {
        #region [ Events ]
        public ICommand Command_Search { get; private set; }
        #endregion

        #region [ Fields ]
        ReaderWriterLockSlim locker = new ReaderWriterLockSlim();
        #endregion

        #region [ Constructor ]
        public Q3ViewModel()
        {
            //Read the dictionary from a text file
            string dllDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string str_dictionary = ReadTextFromFile(Path.Combine(dllDir, "Files", "Dictionary.txt"));

            //Dictionary cannot be empty!
            //if (string.IsNullOrWhiteSpace(str_dictionary))
            //{
            //    System.Windows.MessageBox.Show("Dictionary cannot be empty!", "Validation Error");
            //    CloseWindowExecute();
            //    return;
            //}
            if (!string.IsNullOrWhiteSpace(str_dictionary))
                strList_Dictionary = str_dictionary.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries).Select(current => current.Trim()).ToList();

            Command_Search = new RelayCommand(() => Search(), () => true);
        }
        #endregion

        #region [ Methods ]
        public void Search()
        {
            MatchingResultModels.Clear();

            try
            {
                #region [ Validation ]
                if (string.IsNullOrWhiteSpace(InputText))
                {
                    System.Windows.MessageBox.Show("InputText cannot be empty!", "Validation Error");
                    return;
                }
                #endregion

                //Invoke Compare Function
                List<string> strList_Ret = Compare(InputText);

                foreach (var item in strList_Ret)
                {
                    MatchingResultModels.Add(new MatchingResultModel()
                    {
                        Word = item
                    });
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message.ToString(), "System Error");
                return;
            }
        }

        private List<string> Compare(string str_InputText)
        {
            List<string> ret = new List<string>();
            for (int i = 0; i < str_InputText.Length; ++i)
            {
                for (int j = str_InputText.Length - i; j > 0; --j)
                {
                    string str_SubStr = str_InputText.Substring(i, j).Trim();

                    //Case-insensitive
                    ret.AddRange(strList_Dictionary.Where(current => current.ToLower() == str_SubStr.ToLower()).ToList());
                }
            }
            if (ret.Count() > 0)
            {
                ret = ret.Distinct().ToList();
            }
            return ret;
        }

        public String ReadTextFromFile(String path)
        {
            string ret = "";
            locker.EnterReadLock();
            try
            {
                if (File.Exists(path))
                    using (TextReader streamReader = new StreamReader(path))
                    {
                        ret = streamReader.ReadToEnd();
                    }
            }
            finally
            {
                locker.ExitReadLock();
            }
            GC.Collect();
            return ret;
        }
        #endregion

        #region [ Properties ]
        #region [ Dictionary ]
        public List<string> strList_Dictionary { get; set; }
        #endregion

        #region [ InputText ]
        /// <summary>
        /// The <see cref="Distance" /> property's name.
        /// </summary>
        public const string InputTextPropertyName = "InputText";

        private string _InputText = "";

        /// <summary>
        /// Sets and gets the Distance property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public string InputText
        {
            get
            {
                return _InputText;
            }

            set
            {
                if (_InputText == value)
                {
                    return;
                }

                _InputText = value;

                if (!string.IsNullOrWhiteSpace(_InputText))
                    _CMDIsEnabled = true;
                else
                    _CMDIsEnabled = false;
                RaisePropertyChanged(CMDIsEnabledPropertyName);

                RaisePropertyChanged(InputTextPropertyName);
            }
        }
        #endregion

        #region [ CMDIsEnabled ]
        /// <summary>
        /// The <see cref="CMDIsEnabled" /> property's name.
        /// </summary>
        public const string CMDIsEnabledPropertyName = "CMDIsEnabled";

        private bool _CMDIsEnabled = false;

        /// <summary>
        /// Sets and gets the Path property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public bool CMDIsEnabled
        {
            get
            {
                return _CMDIsEnabled;
            }

            set
            {
                if (_CMDIsEnabled == value)
                {
                    return;
                }

                _CMDIsEnabled = value;
                RaisePropertyChanged(CMDIsEnabledPropertyName);
            }
        }
        #endregion

        #region [ MatchingResult ]
        /// <summary>
        /// The <see cref="MatchingResultModels" /> property's name.
        /// </summary>
        public const string MatchingResultModelsPropertyName = "MatchingResultModels";

        private ObservableCollection<MatchingResultModel> _MatchingResultModels = new ObservableCollection<MatchingResultModel>();

        /// <summary>
        /// Sets and gets the Members property.
        /// Changes to that property's value raise the PropertyChanged event. 
        /// </summary>
        public ObservableCollection<MatchingResultModel> MatchingResultModels
        {
            get
            {
                return _MatchingResultModels;
            }

            set
            {
                if (_MatchingResultModels == value)
                {
                    return;
                }

                _MatchingResultModels = value;
                RaisePropertyChanged(MatchingResultModelsPropertyName);
            }
        }
        #endregion
        #endregion

        #region [ Close Window Event ]
        public override void Cleanup()
        {
            InputText = "";
            CMDIsEnabled = false;
            MatchingResultModels.Clear();
        }

        private void CloseWindowExecute()
        {
            CloseExecute();
        }

        public event EventHandler<EventArgs> RequestClose;
        private void CloseExecute()
        {
            var handler = RequestClose;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        #endregion
    }
}
