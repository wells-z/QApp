﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;

namespace QApp.Controls
{
    public enum TextLimit
    {
        None,
        Number,
        Upper,
        Lower
    }

    public class ExTextBox : System.Windows.Controls.TextBox
    {
        static ExTextBox()
        {
            AutomationProperties.AutomationIdProperty.OverrideMetadata(typeof(ExTextBox), new UIPropertyMetadata("ExTextBox"));
        }

        public TextLimit TextLimit
        {
            get
            {
                return (TextLimit)GetValue(TextLimitProperty);
            }
            set
            {
                SetValue(TextLimitProperty, value);
            }
        }

        public static readonly DependencyProperty TextLimitProperty =
            DependencyProperty.Register("TextLimit", typeof(TextLimit), typeof(ExTextBox),
          new UIPropertyMetadata(TextLimit.None));

        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            if (TextLimit == TextLimit.Number)
            {
                TextChange[] change = new TextChange[e.Changes.Count];
                e.Changes.CopyTo(change, 0);

                int offset = change[0].Offset;
                if (change[0].AddedLength > 0)
                {
                    double num = 0;
                    if (!Double.TryParse(this.Text, out num))
                    {
                        this.Text = this.Text.Remove(offset, change[0].AddedLength);
                        this.Select(offset, 0);
                    }
                }
            }
            base.OnTextChanged(e);
        }

        protected override void OnKeyDown(System.Windows.Input.KeyEventArgs e)
        {

            if (TextLimit == TextLimit.Number)
            {

                if ((e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) || e.Key == Key.Decimal)
                {
                    if (this.Text.Contains(".") && e.Key == Key.Decimal)
                    {
                        e.Handled = true;
                        return;
                    }
                    e.Handled = false;
                }
                else if (((e.Key >= Key.D0 && e.Key <= Key.D9) || e.Key == Key.OemPeriod) && e.KeyboardDevice.Modifiers != ModifierKeys.Shift)
                {
                    if (this.Text.Contains(".") && e.Key == Key.OemPeriod)
                    {
                        e.Handled = true;
                        return;
                    }
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }

            }


        }

        protected override void OnKeyUp(System.Windows.Input.KeyEventArgs e)
        {
            base.OnKeyUp(e);

            if (TextLimit == TextLimit.Upper)
            {
                if (e.Key >= Key.A && e.Key <= Key.Z)
                {
                    int selectionStart = this.SelectionStart;
                    this.Text = this.Text.ToUpper();
                    this.SelectionStart = selectionStart;
                }

            }
            else if (TextLimit == TextLimit.Lower)
            {
                if (e.Key >= Key.A && e.Key <= Key.Z)
                {
                    int selectionStart = this.SelectionStart;
                    this.Text = this.Text.ToLower();
                    this.SelectionStart = selectionStart;
                }

            }
        }
    }
}
