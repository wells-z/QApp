﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QApp.Model
{
    public class FileModel
    {
        public string FileName { get; set; }

        public string FileFullPath { get; set; }

        public FileModel()
        {

        }

        public FileModel(string str_FileFullPath)
        {
            if (!string.IsNullOrWhiteSpace(str_FileFullPath))
            {
                FileFullPath = str_FileFullPath;

                FileName = str_FileFullPath.Substring(str_FileFullPath.LastIndexOf(@"\") + 1);
            }
        }
    }
}
